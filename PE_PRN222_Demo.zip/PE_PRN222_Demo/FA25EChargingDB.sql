﻿
IF DB_ID('FA25EChargingDB') IS NOT NULL
    DROP DATABASE FA25EChargingDB;
GO

-- TẠO DATABASE
CREATE DATABASE FA25EChargingDB;
GO
USE FA25EChargingDB;
GO

-- 2BẢNG SYSTEMUSER  (AUTH + ROLE) -------------------------
CREATE TABLE SystemUser (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(50) NOT NULL UNIQUE,
    UserPassword NVARCHAR(100) NOT NULL,
    UserRole INT NOT NULL, -- 1=Admin, 2=Manager, 3=Staff, 4=Driver
    RegistrationDate DATETIME DEFAULT GETDATE()
);
GO

-- 🔑 Chèn dữ liệu người dùng
INSERT INTO SystemUser (Username, UserPassword, UserRole, RegistrationDate) VALUES
('admin', '123', 1, GETDATE()),     -- Admin
('manager', '123', 2, GETDATE()),   -- Manager
('staffuser', '123', 3, GETDATE()), -- Staff
('driver1', '123', 4, GETDATE()),   -- Driver 1
('driver2', '123', 4, GETDATE());   -- Driver 2
GO

-- BẢNG CHARGINGSTATION  -------------------------
CREATE TABLE ChargingStation (
    StationID INT PRIMARY KEY IDENTITY(1,1),
    StationName NVARCHAR(100) NOT NULL,
    Location NVARCHAR(200),
    MaxPower DECIMAL(10, 2)
);
GO

--  Chèn Trạm sạc mẫu
INSERT INTO ChargingStation (StationName, Location, MaxPower) VALUES
('Station Alpha', 'District 1, HCM', 150.00),
('Station Beta', 'District 7, HCM', 100.50),
('Station Gamma', 'Hanoi Central', 200.00);
GO

-- BẢNG CHARGINGSESSION (Giao dịch chính) ------------------
CREATE TABLE ChargingSession (
    SessionID INT PRIMARY KEY IDENTITY(1,1),
    StationID INT NOT NULL,
    DriverID INT NOT NULL,
    StartTime DATETIME NOT NULL,
    EndTime DATETIME NOT NULL,
    KWhConsumed DECIMAL(10, 3) NOT NULL,
    Cost DECIMAL(18, 2) NOT NULL,
    FOREIGN KEY (StationID) REFERENCES ChargingStation(StationID),
    FOREIGN KEY (DriverID) REFERENCES SystemUser(UserID)
);
GO

DECLARE @Driver1ID INT = (SELECT UserID FROM SystemUser WHERE Username = 'driver1');
DECLARE @Driver2ID INT = (SELECT UserID FROM SystemUser WHERE Username = 'driver2');
DECLARE @StationAlpha INT = (SELECT StationID FROM ChargingStation WHERE StationName = 'Station Alpha');
DECLARE @StationBeta INT = (SELECT StationID FROM ChargingStation WHERE StationName = 'Station Beta');
DECLARE @StationGamma INT = (SELECT StationID FROM ChargingStation WHERE StationName = 'Station Gamma');

INSERT INTO ChargingSession (StationID, DriverID, StartTime, EndTime, KWhConsumed, Cost) VALUES
(@StationAlpha, @Driver1ID, DATEADD(hour, -1, GETDATE()), GETDATE(), 15.000, 50000.00),

(@StationAlpha, @Driver2ID, DATEADD(day, -1, GETDATE()), DATEADD(hour, -1, GETDATE()), 40.500, 120000.00),

(@StationBeta, @Driver1ID, DATEADD(day, -2, GETDATE()), DATEADD(minute, 3, DATEADD(day, -2, GETDATE())), 1.100, 1500.00),

(@StationGamma, @Driver2ID, DATEADD(day, -3, GETDATE()), DATEADD(minute, 6, DATEADD(day, -3, GETDATE())), 2.500, 2500.00),

(@StationBeta, @Driver1ID, DATEADD(day, -4, GETDATE()), DATEADD(minute, 45, DATEADD(day, -4, GETDATE())), 10.123, 45000.00),

(@StationGamma, @Driver1ID, DATEADD(day, -5, GETDATE()), DATEADD(hour, 2, DATEADD(day, -5, GETDATE())), 30.000, 80000.00),

(@StationAlpha, @Driver2ID, DATEADD(day, -6, GETDATE()), DATEADD(hour, 1, DATEADD(day, -6, GETDATE())), 16.000, 55000.00),

(@StationBeta, @Driver2ID, DATEADD(day, -7, GETDATE()), DATEADD(minute, 30, DATEADD(day, -7, GETDATE())), 5.000, 12000.00),

(@StationGamma, @Driver1ID, DATEADD(day, -8, GETDATE()), DATEADD(hour, 5, DATEADD(day, -8, GETDATE())), 60.000, 180000.00),

(@StationAlpha, @Driver1ID, DATEADD(day, -9, GETDATE()), DATEADD(hour, 2, DATEADD(day, -9, GETDATE())), 22.000, 70000.00),

(@StationBeta, @Driver1ID, DATEADD(day, -10, GETDATE()), DATEADD(minute, 4, DATEADD(day, -10, GETDATE())), 2.000, 13000.00),

(@StationGamma, @Driver2ID, DATEADD(day, -11, GETDATE()), DATEADD(minute, 15, DATEADD(day, -11, GETDATE())), 5.500, 45000.00),

(@StationAlpha, @Driver2ID, DATEADD(day, -12, GETDATE()), DATEADD(hour, 1, DATEADD(day, -12, GETDATE())), 8.000, 11000.00),

(@StationBeta, @Driver1ID, DATEADD(day, -13, GETDATE()), DATEADD(hour, 2, DATEADD(day, -13, GETDATE())), 55.750, 220000.00),

(@StationGamma, @Driver1ID, DATEADD(day, -14, GETDATE()), DATEADD(hour, 3, DATEADD(day, -14, GETDATE())), 18.250, 73000.00),

(@StationAlpha, @Driver2ID, DATEADD(day, -15, GETDATE()), DATEADD(hour, 2, DATEADD(day, -15, GETDATE())), 12.500, 50000.00),

(@StationBeta, @Driver1ID, DATEADD(day, -16, GETDATE()), DATEADD(hour, 3, DATEADD(day, -16, GETDATE())), 25.000, 90000.00),

(@StationGamma, @Driver2ID, DATEADD(day, -17, GETDATE()), DATEADD(hour, 7, DATEADD(day, -17, GETDATE())), 48.300, 160000.00),

(@StationAlpha, @Driver1ID, DATEADD(day, -18, GETDATE()), DATEADD(minute, 3, DATEADD(day, -18, GETDATE())), 1.200, 1400.00),

(@StationBeta, @Driver2ID, DATEADD(day, -19, GETDATE()), DATEADD(hour, 2, DATEADD(day, -19, GETDATE())), 21.000, 68000.00)
GO

