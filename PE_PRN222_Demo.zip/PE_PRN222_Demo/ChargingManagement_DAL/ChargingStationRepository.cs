using ChargingManagement_DAL.Basic;
using ChargingManagement_DAL.DBContext;
using ChargingManagement_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChargingManagement_DAL
{
    public class ChargingStationRepository : GenericRepository<ChargingStation>
    {
        public ChargingStationRepository()
        {
        }

        public ChargingStationRepository(FA25EChargingDBContext context) : base(context)
        {
        }
    }
}

