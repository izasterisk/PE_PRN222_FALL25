using ChargingManagement_DAL.Basic;
using ChargingManagement_DAL.DBContext;
using ChargingManagement_DAL.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChargingManagement_DAL
{
    public class SystemUserRepository : GenericRepository<SystemUser>
    {
        public SystemUserRepository()
        {
        }

        public SystemUserRepository(FA25EChargingDBContext context) : base(context)
        {
        }

        public async Task<SystemUser?> GetByUsernameAndPasswordAsync(string username, string password)
        {
            return await _context.SystemUsers
                .FirstOrDefaultAsync(u => u.Username == username && u.UserPassword == password);
        }
    }
}

