using ChargingManagement_DAL.Basic;
using ChargingManagement_DAL.DBContext;
using ChargingManagement_DAL.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChargingManagement_DAL
{
    public class ChargingSessionRepository : GenericRepository<ChargingSession>
    {
        public ChargingSessionRepository()
        {
        }

        public ChargingSessionRepository(FA25EChargingDBContext context) : base(context)
        {
        }

        public new async Task<List<ChargingSession>> GetAllAsync()
        {
            var items = await _context.ChargingSessions
                .Include(c => c.Station)
                .OrderByDescending(c => c.StartTime)
                .ToListAsync();
            return items ?? new List<ChargingSession>();
        }

        public new async Task<ChargingSession?> GetByIdAsync(int id)
        {
            return await _context.ChargingSessions
                .Include(c => c.Station)
                .FirstOrDefaultAsync(c => c.SessionId == id);
        }

        public async Task<List<ChargingSession>> SearchAsync(
            List<string>? stationNames,
            decimal? minCost,
            decimal? maxCost,
            DateTime? startTimeFrom,
            DateTime? startTimeTo)
        {
            var query = _context.ChargingSessions
                .Include(c => c.Station)
                .AsQueryable();

            if (stationNames != null && stationNames.Any())
            {
                query = query.Where(c => stationNames.Contains(c.Station!.StationName));
            }

            if (minCost.HasValue)
            {
                query = query.Where(c => c.Cost >= minCost.Value);
            }

            if (maxCost.HasValue)
            {
                query = query.Where(c => c.Cost <= maxCost.Value);
            }

            if (startTimeFrom.HasValue)
            {
                query = query.Where(c => c.StartTime >= startTimeFrom.Value);
            }

            if (startTimeTo.HasValue)
            {
                query = query.Where(c => c.StartTime <= startTimeTo.Value);
            }

            return await query
                .OrderByDescending(c => c.StartTime)
                .ToListAsync();
        }
    }
}

