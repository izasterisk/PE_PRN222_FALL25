﻿using ChargingManagement_BLL;
using ChargingManagement_DAL.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Claims;
using ChargingSessionModel = ChargingManagement_DAL.Models.ChargingSession;

namespace ChargingManagement_Hieult.Pages.ChargingSessions;

[Authorize]
public class IndexModel : PageModel
{
    private readonly IChargingSessionService _chargingSessionService;

    public IndexModel(IChargingSessionService chargingSessionService)
    {
        _chargingSessionService = chargingSessionService;
    }

    public IList<ChargingSessionModel> ChargingSessions { get; set; } = new List<ChargingSessionModel>();
    
    public int? UserRole { get; set; }
    public bool IsAdmin { get; set; }

    public async Task OnGetAsync()
    {
        var roleClaim = User.FindFirst(ClaimTypes.Role)?.Value;
        if (roleClaim != null && int.TryParse(roleClaim, out var roleId))
        {
            UserRole = roleId;
            IsAdmin = roleId == 1;
        }

        ChargingSessions = await _chargingSessionService.GetAllAsync();
    }
}
