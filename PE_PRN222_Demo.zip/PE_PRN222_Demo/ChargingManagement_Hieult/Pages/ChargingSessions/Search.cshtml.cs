using ChargingManagement_BLL;
using ChargingManagement_DAL.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Claims;
using ChargingSessionModel = ChargingManagement_DAL.Models.ChargingSession;

namespace ChargingManagement_Hieult.Pages.ChargingSessions;

[Authorize]
public class SearchModel : PageModel
{
    private readonly IChargingSessionService _chargingSessionService;
    private readonly IChargingStationService _chargingStationService;

    public SearchModel(IChargingSessionService chargingSessionService, IChargingStationService chargingStationService)
    {
        _chargingSessionService = chargingSessionService;
        _chargingStationService = chargingStationService;
    }

    [BindProperty(SupportsGet = true)]
    public List<string>? StationNames { get; set; }

    [BindProperty(SupportsGet = true)]
    public decimal? MinCost { get; set; }

    [BindProperty(SupportsGet = true)]
    public decimal? MaxCost { get; set; }

    [BindProperty(SupportsGet = true)]
    public DateTime? StartTimeFrom { get; set; }

    [BindProperty(SupportsGet = true)]
    public DateTime? StartTimeTo { get; set; }

    public List<ChargingStation> AllStations { get; set; } = new();
    public List<string>? SelectedStationNames { get; set; }
    public Dictionary<string, List<ChargingSessionModel>> GroupedResults { get; set; } = new();
    public decimal TotalRevenue { get; set; }
    public decimal AverageKWh { get; set; }
    public bool HasSearched { get; set; }
    
    public int? UserRole { get; set; }
    public bool IsAdmin { get; set; }

    public async Task OnGetAsync()
    {
        var roleClaim = User.FindFirst(ClaimTypes.Role)?.Value;
        if (roleClaim != null && int.TryParse(roleClaim, out var roleId))
        {
            UserRole = roleId;
            IsAdmin = roleId == 1;
        }

        AllStations = await _chargingStationService.GetAllAsync();

        if (StationNames != null && StationNames.Any() || MinCost.HasValue || MaxCost.HasValue || StartTimeFrom.HasValue || StartTimeTo.HasValue)
        {
            HasSearched = true;

            if (MinCost == null || MinCost < 10000)
            {
                MinCost = 10000;
            }
            if (MaxCost == null || MaxCost > 150000)
            {
                MaxCost = 150000;
            }

            if (StartTimeFrom == null)
            {
                StartTimeFrom = new DateTime(2025, 9, 1);
            }
            if (StartTimeTo == null)
            {
                StartTimeTo = new DateTime(2025, 9, 30, 23, 59, 59);
            }

            var results = await _chargingSessionService.SearchAsync(StationNames, MinCost, MaxCost, StartTimeFrom, StartTimeTo);

            GroupedResults = results
                .Where(s => s.Station != null)
                .GroupBy(s => s.Station!.StationName)
                .ToDictionary(g => g.Key, g => g.ToList());

            SelectedStationNames = StationNames;

            var allSessions = results;
            TotalRevenue = allSessions.Sum(s => s.Cost);
            AverageKWh = allSessions.Any() ? allSessions.Average(s => s.KwhConsumed) : 0;
        }
    }
}

