﻿using ChargingManagement_BLL;
using ChargingManagement_DAL.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ChargingSessionModel = ChargingManagement_DAL.Models.ChargingSession;

namespace ChargingManagement_Hieult.Pages.ChargingSessions;

[Authorize(Roles = "1,2")]
public class CreateModel : PageModel
{
    private readonly IChargingSessionService _chargingSessionService;
    private readonly IChargingStationService _chargingStationService;

    public CreateModel(IChargingSessionService chargingSessionService, IChargingStationService chargingStationService)
    {
        _chargingSessionService = chargingSessionService;
        _chargingStationService = chargingStationService;
    }

    [BindProperty]
    public ChargingSessionModel ChargingSession { get; set; } = new();

    public SelectList Stations { get; set; } = default!;
    public SelectList Drivers { get; set; } = default!;

    public async Task<IActionResult> OnGetAsync()
    {
        var stations = await _chargingStationService.GetAllAsync();
        var stationList = stations.Select(s => new { Id = s.StationId, Display = $"{s.StationId} - {s.StationName}" }).ToList();
        Stations = new SelectList(stationList, "Id", "Display");

        var drivers = new List<object> { new { Id = 1, Display = "1 - Driver 1" } };
        Drivers = new SelectList(drivers, "Id", "Display");

        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (ChargingSession.StationId <= 0)
        {
            ModelState.AddModelError("ChargingSession.StationId", "Please select a Station.");
        }

        if (ChargingSession.DriverId <= 0)
        {
            ModelState.AddModelError("ChargingSession.DriverId", "Please select a Driver.");
        }

        if (ChargingSession.KwhConsumed <= 0)
        {
            ModelState.AddModelError("ChargingSession.KwhConsumed", "KWh Consumed must be a positive number (greater than 0).");
        }
        else
        {
            var kwhString = ChargingSession.KwhConsumed.ToString("F3");
            var decimalPlaces = kwhString.Contains('.') ? kwhString.Split('.')[1].Length : 0;
            if (decimalPlaces > 3)
            {
                ModelState.AddModelError("ChargingSession.KwhConsumed", "KWh Consumed allows up to 3 decimal places.");
            }
        }

        if (ChargingSession.Cost <= 0)
        {
            ModelState.AddModelError("ChargingSession.Cost", "Cost must be a positive number.");
        }
        else if (ChargingSession.Cost <= 1000)
        {
            ModelState.AddModelError("ChargingSession.Cost", "Cost must be greater than 1000.");
        }

        var now = DateTime.Now;
        if (ChargingSession.StartTime > now)
        {
            ModelState.AddModelError("ChargingSession.StartTime", "Start Time cannot be a future date.");
        }

        if (ChargingSession.EndTime > now)
        {
            ModelState.AddModelError("ChargingSession.EndTime", "End Time cannot be a future date.");
        }

        if (ChargingSession.EndTime <= ChargingSession.StartTime)
        {
            ModelState.AddModelError("ChargingSession.EndTime", "End Time must be after Start Time.");
        }

        if (!ModelState.IsValid)
        {
            var stations = await _chargingStationService.GetAllAsync();
            var stationList = stations.Select(s => new { Id = s.StationId, Display = $"{s.StationId} - {s.StationName}" }).ToList();
            Stations = new SelectList(stationList, "Id", "Display");

            var drivers = new List<object> { new { Id = 1, Display = "1 - Driver 1" } };
            Drivers = new SelectList(drivers, "Id", "Display");

            return Page();
        }

        await _chargingSessionService.CreateAsync(ChargingSession);
        return RedirectToPage("./Index");
    }
}
