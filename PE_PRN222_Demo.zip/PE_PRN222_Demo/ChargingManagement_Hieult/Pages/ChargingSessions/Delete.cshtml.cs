﻿using ChargingManagement_BLL;
using ChargingManagement_DAL.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ChargingSessionModel = ChargingManagement_DAL.Models.ChargingSession;

namespace ChargingManagement_Hieult.Pages.ChargingSessions;

[Authorize(Roles = "1,2")]
public class DeleteModel : PageModel
{
    private readonly IChargingSessionService _chargingSessionService;

    public DeleteModel(IChargingSessionService chargingSessionService)
    {
        _chargingSessionService = chargingSessionService;
    }

    public ChargingSessionModel? ChargingSession { get; set; }

    public async Task<IActionResult> OnGetAsync(int id)
    {
        ChargingSession = await _chargingSessionService.GetByIdAsync(id);
        if (ChargingSession == null)
        {
            return NotFound();
        }
        return Page();
    }

    public async Task<IActionResult> OnPostAsync(int id)
    {
        var session = await _chargingSessionService.GetByIdAsync(id);
        if (session != null)
        {
            await _chargingSessionService.DeleteAsync(id);
        }
        return RedirectToPage("./Index");
    }
}
