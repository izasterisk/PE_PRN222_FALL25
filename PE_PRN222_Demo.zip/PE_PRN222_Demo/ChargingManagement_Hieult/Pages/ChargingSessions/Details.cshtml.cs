﻿using ChargingManagement_BLL;
using ChargingManagement_DAL.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Claims;
using ChargingSessionModel = ChargingManagement_DAL.Models.ChargingSession;

namespace ChargingManagement_Hieult.Pages.ChargingSessions;

[Authorize]
public class DetailsModel : PageModel
{
    private readonly IChargingSessionService _chargingSessionService;

    public DetailsModel(IChargingSessionService chargingSessionService)
    {
        _chargingSessionService = chargingSessionService;
    }

    public ChargingSessionModel? ChargingSession { get; set; }
    
    public int? UserRole { get; set; }
    public bool IsAdmin { get; set; }

    public async Task<IActionResult> OnGetAsync(int id)
    {
        var roleClaim = User.FindFirst(ClaimTypes.Role)?.Value;
        if (roleClaim != null && int.TryParse(roleClaim, out var roleId))
        {
            UserRole = roleId;
            IsAdmin = roleId == 1;
        }

        ChargingSession = await _chargingSessionService.GetByIdAsync(id);
        if (ChargingSession == null)
        {
            return NotFound();
        }
        return Page();
    }
}
