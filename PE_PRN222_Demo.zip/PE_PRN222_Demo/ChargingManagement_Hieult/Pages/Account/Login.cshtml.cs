using ChargingManagement_BLL;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Claims;

namespace ChargingManagement_Hieult.Pages.Account
{
    [Microsoft.AspNetCore.Authorization.AllowAnonymous]
    public class LoginModel : PageModel
    {
        private readonly SystemUserService _userService;

        public LoginModel()
        {
            _userService = new SystemUserService();
        }

        [BindProperty]
        public string Username { get; set; } = string.Empty;

        [BindProperty]
        public string Password { get; set; } = string.Empty;

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var userAccount = await _userService.GetAccount(Username, Password);

            if (userAccount != null)
            {
                if (userAccount.UserRole == 4)
                {
                    TempData["Message"] = "Driver role is not allowed to access the management interface!";
                    return Page();
                }

                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, Username),
                    new Claim(ClaimTypes.Role, userAccount.UserRole.ToString()),
                };

                var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));

                Response.Cookies.Append("UserName", userAccount.Username);

                return RedirectToPage("/ChargingSessions/Index");
            }
            else
            {
                TempData["Message"] = "Invalid Username or Password!";
            }

            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return Page();
        }
    }
}

