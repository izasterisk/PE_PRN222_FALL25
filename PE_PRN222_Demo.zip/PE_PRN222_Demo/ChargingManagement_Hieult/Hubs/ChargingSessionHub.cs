using ChargingManagement_BLL;
using Microsoft.AspNetCore.SignalR;
using System;

namespace ChargingManagement_Hieult.Hubs;

public class ChargingSessionHub : Hub
{
    private readonly IChargingSessionService _chargingSessionService;

    public ChargingSessionHub(IChargingSessionService chargingSessionService)
    {
        _chargingSessionService = chargingSessionService;
    }

    public async Task HubDelete_ChargingSession(int sessionId)
    {
        try
        {
            var deleted = await _chargingSessionService.DeleteAsync(sessionId);
            if (deleted)
            {
                await Clients.All.SendAsync("ReceiveDeleteNotification", sessionId);
            }
        }
        catch (Exception ex)
        {
            await Clients.Caller.SendAsync("ReceiveError", ex.Message);
        }
    }
}

