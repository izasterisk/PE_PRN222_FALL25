using ChargingManagement_DAL;
using ChargingManagement_DAL.Models;

namespace ChargingManagement_BLL;

public class ChargingSessionService : IChargingSessionService
{
    private readonly ChargingSessionRepository _repository;

    public ChargingSessionService()
    {
        _repository = new ChargingSessionRepository();
    }

    public async Task<List<ChargingSession>> GetAllAsync()
    {
        return await _repository.GetAllAsync();
    }

    public async Task<ChargingSession?> GetByIdAsync(int id)
    {
        return await _repository.GetByIdAsync(id);
    }

    public async Task<List<ChargingSession>> SearchAsync(
        List<string>? stationNames,
        decimal? minCost,
        decimal? maxCost,
        DateTime? startTimeFrom,
        DateTime? startTimeTo)
    {
        return await _repository.SearchAsync(stationNames, minCost, maxCost, startTimeFrom, startTimeTo);
    }

    public async Task<int> CreateAsync(ChargingSession session)
    {
        return await _repository.CreateAsync(session);
    }

    public async Task<int> UpdateAsync(ChargingSession session)
    {
        return await _repository.UpdateAsync(session);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var item = await _repository.GetByIdAsync(id);
        if (item != null)
        {
            return await _repository.RemoveAsync(item);
        }
        return false;
    }
}

