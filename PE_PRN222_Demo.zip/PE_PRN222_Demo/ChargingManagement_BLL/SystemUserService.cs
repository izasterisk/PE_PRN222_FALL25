using ChargingManagement_DAL;
using ChargingManagement_DAL.Models;

namespace ChargingManagement_BLL;

public class SystemUserService
{
    private readonly SystemUserRepository _repository;

    public SystemUserService()
    {
        _repository = new SystemUserRepository();
    }

    public async Task<SystemUser?> GetAccount(string username, string password)
    {
        return await _repository.GetByUsernameAndPasswordAsync(username, password);
    }
}

