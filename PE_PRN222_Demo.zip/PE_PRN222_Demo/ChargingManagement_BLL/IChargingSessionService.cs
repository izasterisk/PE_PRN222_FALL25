using ChargingManagement_DAL.Models;

namespace ChargingManagement_BLL;

public interface IChargingSessionService
{
    Task<List<ChargingSession>> GetAllAsync();
    Task<ChargingSession?> GetByIdAsync(int id);
    Task<List<ChargingSession>> SearchAsync(
        List<string>? stationNames,
        decimal? minCost,
        decimal? maxCost,
        DateTime? startTimeFrom,
        DateTime? startTimeTo);
    Task<int> CreateAsync(ChargingSession session);
    Task<int> UpdateAsync(ChargingSession session);
    Task<bool> DeleteAsync(int id);
}

