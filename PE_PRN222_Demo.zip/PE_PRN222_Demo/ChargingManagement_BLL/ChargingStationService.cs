using ChargingManagement_DAL;
using ChargingManagement_DAL.Models;

namespace ChargingManagement_BLL;

public class ChargingStationService : IChargingStationService
{
    private readonly ChargingStationRepository _repository;

    public ChargingStationService()
    {
        _repository = new ChargingStationRepository();
    }

    public async Task<List<ChargingStation>> GetAllAsync()
    {
        return await _repository.GetAllAsync();
    }
}

