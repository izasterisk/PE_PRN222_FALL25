using ChargingManagement_DAL.Models;

namespace ChargingManagement_BLL;

public interface IChargingStationService
{
    Task<List<ChargingStation>> GetAllAsync();
}

